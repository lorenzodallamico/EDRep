import numpy as np
from node2vec.model import Node2Vec

def computeZ(X : np.ndarray, indeces : np.ndarray):
    '''This function computes the exact value of Z_i for a set of indeces i

    Use: Z_vec = computeZ(X, indeces)

    Inputs:
        * X (array): input embedding matrix
        * indeces (array): indices for which Z_i should be computed

    Output:
        * Z_vec (array): array containing the Z_i values corresponding to the indeces
    '''

    Z_vec = np.sum(np.exp(X[indeces]@X.T), axis = 1)

    return Z_vec



def Node2VecNS(A, dim: int, verbose: bool):
    '''This function compute the Node2Vec embedding with negative sampling, using the standard function parameters
    
    Use: X = Node2Vec(A, dim, verbose)
    
    Input: 
        * A (sparse csr_matrix): sparse adjacency matrix of the graph
        * dim (int): embedding dimensionality
        * verbose (bool): sets the level of verbosity
        
    Output:
        * X (array): embedding matrix
        
    '''

    src_nodes, dest_nodes = A.nonzero()
    node2vec_model = Node2Vec(src_nodes, dest_nodes, graph_is_directed = False)
    node2vec_model.simulate_walks(workers = 8, verbose = verbose, p = 1, q = 1)
    node2vec_model.learn_embeddings(dimensions = dim, workers = 8, verbose = verbose)
    X = node2vec_model.embeddings

    return X